﻿
namespace Gui_Prime
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.inputNumber1 = new System.Windows.Forms.TextBox();
            this.inputNumber2 = new System.Windows.Forms.TextBox();
            this.outputNumber = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(311, 185);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(132, 76);
            this.button1.TabIndex = 0;
            this.button1.Text = "Calculate";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // inputNumber1
            // 
            this.inputNumber1.Location = new System.Drawing.Point(118, 25);
            this.inputNumber1.Multiline = true;
            this.inputNumber1.Name = "inputNumber1";
            this.inputNumber1.PlaceholderText = "Enter in 1st number";
            this.inputNumber1.Size = new System.Drawing.Size(182, 132);
            this.inputNumber1.TabIndex = 1;
            this.inputNumber1.TextChanged += new System.EventHandler(this.inputNumber1_TextChanged);
            // 
            // inputNumber2
            // 
            this.inputNumber2.Location = new System.Drawing.Point(430, 25);
            this.inputNumber2.Multiline = true;
            this.inputNumber2.Name = "inputNumber2";
            this.inputNumber2.PlaceholderText = "Enter in 2nd number";
            this.inputNumber2.Size = new System.Drawing.Size(190, 132);
            this.inputNumber2.TabIndex = 2;
            // 
            // outputNumber
            // 
            this.outputNumber.BackColor = System.Drawing.Color.WhiteSmoke;
            this.outputNumber.Location = new System.Drawing.Point(242, 281);
            this.outputNumber.Multiline = true;
            this.outputNumber.Name = "outputNumber";
            this.outputNumber.PlaceholderText = "Output";
            this.outputNumber.Size = new System.Drawing.Size(280, 204);
            this.outputNumber.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 514);
            this.Controls.Add(this.outputNumber);
            this.Controls.Add(this.inputNumber2);
            this.Controls.Add(this.inputNumber1);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox inputNumber1;
        private System.Windows.Forms.TextBox inputNumber2;
        private System.Windows.Forms.TextBox outputNumber;
    }
}

