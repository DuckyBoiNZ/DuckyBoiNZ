﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gui_Prime
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e) //acknowledges click and runs through numbers between 1st input and 2nd
        {
            List<int> formlist = new List<int>();
            int value1 =  int.Parse(inputNumber1.Text);
            int value2 = int.Parse(inputNumber2.Text);
            for (int i = value1; i <= value2; i++)
            {
                if(isPrime(i) == true)
                {
                    formlist.Add(i);
                    
                }
            }

            int count = 0;
            foreach (int number in formlist) //displays the prime numbers
            {
                if (number == formlist[^1])
                {
                    outputNumber.Text += number.ToString();
                    count++;
                }

                if (count >= 5)
                {
                    outputNumber.Text += Environment.NewLine;
                    count = 0;
                }

                outputNumber.Text += number.ToString() + ", ";
                count++;
            }

           
            



           
        }
        private Boolean isPrime(int n) //creates the isprime to calculate if the number is prime
        {
            Boolean b = true;

            for (int i = 2; i < n; i++)
            {
                if ((n % i) == 0)
                {
                    b = false;
                    break;
                }
            }
            return (b);
        }

        private void inputNumber1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
