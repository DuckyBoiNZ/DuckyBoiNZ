﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inheritaance
{
    
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // make user select txt file
                OpenFileDialog openFileDialog = new OpenFileDialog
                {
                    InitialDirectory = @"C:\",
                    Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*",
                    FilterIndex = 2,
                    RestoreDirectory = true
                };
                //if filename is acceptable, add to box
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    fileBox.Text = openFileDialog.FileName;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        static double getProf(Animal[] myFarm)
        {
            double profit = 0;
            foreach (Animal animal in myFarm)
            {
                profit += animal.getProf();
            }
            return profit;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            textBox6.Clear();
            try
            {
                // gets inputs from 5 text boxes
                Prices.cowMilkPrice = double.Parse(textBox1.Text);
                Prices.goatMilkPrice = double.Parse(textBox2.Text);
                Prices.cowVaccPrice = double.Parse(textBox3.Text);
                Prices.jcowVaccPrice = double.Parse(textBox4.Text);
                Prices.goatVaccPrice = double.Parse(textBox5.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            try
            {
                Animal[] myFarm = new Animal[10];
                System.IO.StreamReader file = new System.IO.StreamReader(fileBox.Text);
                string line;
                int i = 0;
                // goes through each line of the txt file
                while ((line = file.ReadLine()) != null)
                {
                    // splits each line to get id, milkamount and type of animal
                    string[] values = line.Split(',');
                    // checks type of animal, creates object accordingly
                    if (values[2] == "Cow")
                    {
                        myFarm[i] = new Cow(int.Parse(values[0]), double.Parse(values[1]));
                    }
                    else if (values[2] == "Jersey_Cow")
                    {
                        myFarm[i] = new Jersey_cow(int.Parse(values[0]), double.Parse(values[1]));
                    }
                    else if (values[2] == "Goat")
                    {
                        myFarm[i] = new Goat(int.Parse(values[0]), double.Parse(values[1]));
                    }
                    i++;
                }
                file.Close();
                textBox6.Text = "$" + getProf(myFarm).ToString("0.##");
            }
            catch
            {
                MessageBox.Show("Text File Error");
            }
        }
    }
    }
    
    class Goat : Animal
    {
        public double milkAmount;
        public Goat(int id, double milkAmount) : base(id) { this.milkAmount = milkAmount; }

        override public double getProf()
        {
            double income = this.milkAmount * Prices.goatMilkPrice - Prices.goatVaccPrice;
            return (income);
        }

    }
    abstract class Animal
    {
        public int id;
        public Animal(int id)
        {
            this.id = id;
        }
        public abstract double getProf();
    }
    class Cow : Animal
    {
        public double milkAmount;
        public Cow(int id, double milkAmount) : base(id)
        {
            this.milkAmount = milkAmount;
        }

        override public double getProf()
        {
            //The profitability of a livestock is calculated as the income from milk minus the cost of vaccination.
            double income = this.milkAmount * Prices.cowMilkPrice - Prices.cowVaccPrice;
            return (income);
        }
    }
    class Jersey_cow : Cow
    {
        public Jersey_cow(int id, double milkAmount) : base(id, milkAmount) { }

        override public double getProf()
        {
            double income = this.milkAmount * Prices.cowMilkPrice - Prices.jcowVaccPrice;
            return (income);
        }
    }
    class Prices
    {
        public static double cowMilkPrice;
        public static double goatMilkPrice;
        public static double cowVaccPrice;
        public static double jcowVaccPrice;
        public static double goatVaccPrice;

    }
