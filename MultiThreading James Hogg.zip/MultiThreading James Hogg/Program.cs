﻿using System;
using System.Threading;

namespace Multithreading
{
    class Program
    {
        public static int maximum;
        public static int position;
        public static int[] array = new int[10000];

        static void Main(string[] args)
        {
            var watch = new System.Diagnostics.Stopwatch(); //uses the built in stopwatch function to count how long the program takes

            watch.Start();

            Console.WriteLine("This computer uses this many processors", Environment.ProcessorCount); //displays number of processors on current computer


            Random rando = new Random(); //puts random numbers beterrn 1 and 100001 into the array
            for (int i = 0; i < array.Length; i++)
            {
                array[i] = rando.Next(1, 10000);
            }



            Thread thread1 = new Thread(querry1); //creates threads to run the querrys // 65
            Thread thread2 = new Thread(querry2);
            Thread thread3 = new Thread(querry3);
            thread1.Start();
            thread2.Start();
            thread3.Start();

            Thread.Sleep(40);
            Console.WriteLine($"Time to Execute: {watch.ElapsedMilliseconds} ms"); //prints how long it took
            Console.WriteLine("\nThe Largest number is: {0}\nPosition: {1}", max, position); // prints the largest number and position

        }

        public static void querry1()
        {
            for(int i = 0; i < (array.Length) / 2; i++)
            {
                if(array[i] > maximum)
                {
                    maximum = array[i];
                    position = i;
                }
            }
        }
        public static void querry2()
        {
            for (int i = array.Length/2; i < (array.Length); i++)
            {
                if (array[i] > maximum)
                {
                    maximum = array[i];
                    position = i;
                }
            }
        }
        public static void querry3()
        {
            for (int i = array.Length / 2; i < (array.Length); i++)
            {
                if (array[i] > maximum)
                {
                    maximum = array[i];
                    position = i;
                }
            }
        }
        
    }
}
