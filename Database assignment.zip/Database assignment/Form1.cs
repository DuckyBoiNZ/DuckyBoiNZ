﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Database_assignment
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String ConnStr = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source = C:\Users\User\Documents\Wintec\Year 2 Semester 2\App dev assingments\FarmInformation.accdb; Persist Security Info = False";
            //to connect to the database file


            OleDbConnection conn = null;
            try
            {
                string q = null;
                conn = new OleDbConnection(ConnStr);
                conn.Open();
                q = "SELECT * FROM " + "[" + textBox1.Text + "]";
                //textbox fill in
                OleDbCommand cmd = new OleDbCommand(q, conn);
                String str = "";
                using (OleDbDataReader reader = cmd.ExecuteReader())
                {
                    int count = reader.FieldCount;
                    //to help space out the 2nd textbox
                    while (reader.Read())
                    {
                        for (int i = 0; i <= count; i++)
                        {
                            if (count == i)
                            {
                                textBox2.Text = str += "\r\n";
                                break;
                            }
                            textBox2.Text = str += reader[i] + " ,".ToString();
                        }
                        
                    }
                    textBox2.Text = (str);
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                textBox2.Text = (ex.Message);
            }

        }
    }
}
